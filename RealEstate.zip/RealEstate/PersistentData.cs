﻿namespace RealEstate.Models
{
    public class PersistentData
    {
        public static List<Utilisateur> utilisateurs = new List<Utilisateur>()
        {
            new Utilisateur()
            {
                id = 0,
                nom = "BIDJA BISSA",
                prenom = "YVES",
                nomutilisateur = "OpyrusKnight",
                motpasse = "Admin12345",
                numtelephone = "656118542",
                email = "OpyrusKnight@gmail.com"
            }
        };
    }
}
