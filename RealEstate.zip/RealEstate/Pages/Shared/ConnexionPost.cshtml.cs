using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RealEstate.Pages.Shared
{
    public class ConnexionPostModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
