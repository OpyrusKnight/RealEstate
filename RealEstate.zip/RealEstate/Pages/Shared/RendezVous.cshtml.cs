using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RealEstate.Pages.Shared
{
    public class RendezVousModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
