using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RealEstate.Pages.Shared
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
